<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
include(G5_SHOP_SKIN_PATH.'/search.skin.php');