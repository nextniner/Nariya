<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if(!IS_YC) {
	$default['de_admin_company_name'] = '아미나'; // 회사명
	$default['de_admin_company_owner'] = '나리야'; // 대표자명
	$default['de_admin_company_addr'] = 'OO도 OO시 OO구 OO동 123-45'; // 주소
	$default['de_admin_company_saupja_no'] = '123-45-67890'; // 사업자 등록번호
	$default['de_admin_company_tel'] = '02-123-4567'; // 전화
	$default['de_admin_company_fax'] = '02-123-4568'; // 팩스
	$default['de_admin_tongsin_no'] = '제 OO구 - 123호'; // 통신판매업신고
	$default['de_admin_info_name'] = '정보책임자명'; //개인정보관리책임자
}

// 메인이 아닐 경우
if(!IS_INDEX) {
?>
		<?php if(!$is_onecolumn) { // 2단 일 때 ?>
					</div>
				</div>
				<div class="order-2<?php echo $order_right ?> col-md-4 col-lg-3">
					<div class="sticky-top pt-3 pb-0 pb-md-3">
						<?php include_once LAYOUT_PATH.'/component/sidebar.php'; // 사이드바 ?>
					</div>
				</div>
			</div>
		<?php } ?>
		</div>
	</div>
<?php } // 메인이 아닐 경우 ?>

	<footer class="site-footer-wrap bg-body-tertiary py-4">
		<div class="container px-3 text-center">
			
			<!-- 주석처리
			<div class="mb-4">
				<a href="<?php echo get_pretty_url('content', 'company'); ?>">
					사이트 소개
					<i class="bar">&nbsp;</i>
				</a>
				<a href="<?php echo get_pretty_url('content', 'provision'); ?>">
					이용약관
					<i class="bar">&nbsp;</i>
				</a>
				<a href="<?php echo get_pretty_url('content', 'privacy'); ?>">
					개인정보 처리방침
					<i class="bar">&nbsp;</i>
				</a>
				<a href="<?php echo G5_BBS_URL ?>/qalist.php">
					1:1 문의
					<i class="bar">&nbsp;</i>
				</a>
				<a href="<?php echo get_device_change_url(); ?>">
					<?php echo (G5_IS_MOBILE) ? 'PC' : '모바일'; ?> 버전
				</a>
			</div>
			-->

			<div class="lh-lg small mb-3">
				회사명 : <?php echo $default['de_admin_company_name'] ?>
				<span class="bar-sm">&nbsp;</span>
				대표 : <?php echo $default['de_admin_company_owner'] ?>
				<span class="bar-sm">&nbsp;</span>
				주소  : <?php echo $default['de_admin_company_addr'] ?>
				<span class="bar-sm">&nbsp;</span>
				사업자 등록번호  : <?php echo $default['de_admin_company_saupja_no'] ?>
				<span class="bar-sm">&nbsp;</span>
				전화 :  <?php echo $default['de_admin_company_tel'] ?>
				<span class="bar-sm">&nbsp;</span>
				팩스  : <?php echo $default['de_admin_company_fax'] ?>
				<span class="bar-sm">&nbsp;</span>
				통신판매업신고번호 :  <?php echo $default['de_admin_tongsin_no'] ?>
				<span class="bar-sm">&nbsp;</span>
				개인정보관리책임자 :  <?php echo $default['de_admin_info_name'] ?>
			</div>

			<div class="small">
				Copyright &copy; <b><?php $host = @parse_url(G5_URL); echo $host['host'] ?></b>. All rights reserved.
			</div>

		</div>
	</footer>
</div>

<div id="toTop" class="position-fixed bottom-0 end-0 lh-1" style="display:none; z-index:11;">
	<a href="#top" class="d-none d-sm-inline-block fs-1 m-3">
		<i class="bi bi-arrow-up-square-fill"></i>
	</a>
</div>

<div class="d-none">
<?php 
// 오프캔버스 공통 버튼셋	
ob_start(); 
?>
	<div class="d-flex gap-2">
		<a href="<?php echo HOME_URL ?>" class="btn btn-basic btn-sm" title="홈으로">
			<i class="bi bi-house-door"></i>
			<span class="visually-hidden">홈으로</span>
		</a>
		<a href="#menuOffcanvas" class="btn-menu btn btn-basic btn-sm" data-bs-toggle="offcanvas" data-bs-target="#menuOffcanvas" aria-controls="menuOffcanvas" title="전체메뉴">
			<i class="bi bi-list"></i>
			<span class="visually-hidden">전체메뉴</span>
		</a>
		<a href="#loginOffcanvas" class="btn-member btn btn-basic btn-sm" data-bs-toggle="offcanvas" data-bs-target="#memberOffcanvas" aria-controls="memberOffcanvas" title="마이메뉴">
			<i class="bi bi-person-circle"></i>
			<span class="visually-hidden">마이메뉴</span>
		</a>
		<a href="#newOffcanvas" class="btn-new btn btn-basic btn-sm" data-bs-toggle="offcanvas" data-bs-target="#newOffcanvas" aria-controls="newOffcanvas" title="새글/새댓글">
			<i class="bi bi-lightning"></i>
			<span class="visually-hidden">새글/새댓글</span>
		</a>
	<?php if (IS_YC) { ?>
		<?php if(IS_SHOP) { ?>
			<a href="<?php echo G5_URL ?>" class="btn btn-basic btn-sm">
				<i class="bi bi-arrow-right-circle"></i>
				<?php echo $config['cf_title'] ?>
			</a>
		<?php } else { ?>
			<a href="<?php echo G5_SHOP_URL ?>" class="btn btn-basic btn-sm">
				<i class="bi bi-arrow-right-circle"></i>
				<?php echo (isset($nariya['seo_shop_title']) && $nariya['seo_shop_title']) ? $nariya['seo_shop_title'] : '쇼핑몰'; ?>
			</a>
		<?php } ?>
	<?php } ?>
	</div>
<?php
$offcanvas_buttons = ob_get_contents();
ob_end_flush();
?>
</div>

<?php 
// 전체검색 오프캔버스
include_once LAYOUT_PATH.'/component/search.offcanvas.php';

// 모바일 메뉴 오프캔버스
include_once LAYOUT_PATH.'/component/menu.offcanvas.php';

// 멤버 오프캔버스
include_once LAYOUT_PATH.'/component/member.offcanvas.php';  

// 새글 오프캔버스
include_once LAYOUT_PATH.'/component/new.offcanvas.php';  

// 알림 오프캔버스
if($is_member) 
	include_once LAYOUT_PATH.'/component/noti.offcanvas.php';

// 번역 오프캔버스
include_once LAYOUT_PATH.'/component/trans.offcanvas.php';  

// 영카트 쇼핑몰 사용시 출력
if(IS_YC) {
	// 오늘 본 상품 오프캔버스
	include_once LAYOUT_PATH.'/component/todayview.offcanvas.php';

	// 장바구니 오프캔버스
	include_once LAYOUT_PATH.'/component/cart.offcanvas.php';

	// 위시리스트 오프캔버스
	include_once LAYOUT_PATH.'/component/wishlist.offcanvas.php';

	// 이벤트 오프캔버스
	include_once LAYOUT_PATH.'/component/event.offcanvas.php';

	// 사용후기 오프캔버스
	include_once LAYOUT_PATH.'/component/itemuse.offcanvas.php';

	// 상품문의 오프캔버스
	include_once LAYOUT_PATH.'/component/itemqa.offcanvas.php';
}

// 어드민 오프캔버스
if($is_admin === 'super' || IS_DEMO) 
	include_once LAYOUT_PATH.'/component/admin.offcanvas.php';

// 신고 모달
include_once LAYOUT_PATH.'/component/singo.modal.php';

if ($config['cf_analytics'])
    echo $config['cf_analytics'];
?>

<?php if(!G5_IS_MOBILE) { // PC에서만 실행?>
<script src="<?php echo LAYOUT_URL ?>/js/topbar.min.js"></script>
<script src="<?php echo LAYOUT_URL ?>/js/topbar.load.js"></script>
<?php } ?>