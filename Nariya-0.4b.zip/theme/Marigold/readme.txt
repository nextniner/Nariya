Theme Name: Nariya-Marigold Theme
Theme URI: https://amina.co.kr/neo/marigold
Maker: 한별아빠
Maker URI: https://amina.co.kr/neo
Version: 0.1a
Detail: 부트스크랩 5.3 기반의 나리야 마리골드 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html