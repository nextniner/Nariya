<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

require_once(G5_MSHOP_PATH.'/settle_'.$default['de_pg_service'].'.inc.php');

$tablet_size = "1.0"; // 화면 사이즈 조정 - 기기화면에 맞게 수정(갤럭시탭,아이패드 - 1.85, 스마트폰 - 1.0)
?>

<div id="sod_approval_frm">
    <?php
    // 결제대행사별 코드 include (결제등록 필드)
    require_once(G5_MSHOP_PATH.'/'.$default['de_pg_service'].'/orderform.1.php');
    ?>
</div>

<form name="forderform" method="post" action="<?php echo $order_action_url; ?>" autocomplete="off">
<input type="hidden" name="pp_id" value="<?php echo $pp['pp_id']; ?>">

	<div class="row">
		<div class="col-md-7">
			<section id="sod_frm_pay" class="mb-4">
				<h2 class="fs-5 px-3 py-2 mb-0">
					개인결제정보
				</h2>
				<div class="table-responsive line-top">
					<table class="table">
					<tbody>
					<?php if(trim($pp['pp_content'])) { ?>
					<tr>
						<th class="py-3">상세내용</th>
						<td class="py-3"><?php echo conv_content($pp['pp_content'], 0); ?></td>
					</tr>
					<?php } ?>
					<tr>
						<th class="py-3">결제금액</th>
						<td class="py-3"><?php echo display_price($pp['pp_price']); ?></td>
					</tr>
					<tr>
						<th><label for="pp_name">이름<strong class="visually-hidden"> 필수</strong></label></th>
						<td>
							<input type="text" name="pp_name" value="<?php echo get_text($pp['pp_name']); ?>" id="pp_name" required class="required form-control">
						</td>
					</tr>
					<tr>
						<th><label for="pp_hp">휴대폰<strong class="visually-hidden"> 필수</strong></label></th>
						<td><input type="text" name="pp_hp" value="<?php echo get_text($member['mb_hp']); ?>" id="pp_hp" required class="required form-control"></td>
					</tr>
					<tr>
						<th><label for="pp_email">이메일<strong class="visually-hidden"> 필수</strong></label></th>
						<td><input type="text" name="pp_email" value="<?php echo $member['mb_email']; ?>" id="pp_email" required class="required form-control"></td>
					</tr>
					</tbody>
					</table>
				</div>
			</section>
		</div>
		<div class="col-md-5">
			<section id="od_pay_sl" class="mb-4">
				<h2 class="fs-5 px-3 py-2 mb-0">
					결제 수단
				</h2>
				<ul class="list-group list-group-flush line-top">
					<li class="list-group-item">

						<div id="od_pay_sl" class="od_pay_buttons_el clearfix">	
						<?php
						$multi_settle = 0;
						$checked = '';

						$escrow_title = "";
						if ($default['de_escrow_use']) {
							$escrow_title = "에스크로<br>";
						}

						if ($default['de_vbank_use'] || $default['de_iche_use'] || $default['de_card_use'] || $default['de_hp_use']) {
							//echo '<fieldset id="sod_frm_paysel">';
							//echo '<legend>결제방법 선택</legend>';
						}

						// 가상계좌 사용
						if ($default['de_vbank_use']) {
							$multi_settle++;
							echo '<input type="radio" id="od_settle_vbank" name="od_settle_case" value="가상계좌" '.$checked.'> <label for="od_settle_vbank" class="lb_icon vbank_icon">'.$escrow_title.'가상계좌</label>'.PHP_EOL;
							$checked = '';
						}

						// 계좌이체 사용
						if ($default['de_iche_use']) {
							$multi_settle++;
							echo '<input type="radio" id="pp_settle_iche" name="pp_settle_case" value="계좌이체" '.$checked.'> <label for="pp_settle_iche" class="lb_icon iche_icon">'.$escrow_title.'계좌이체</label>'.PHP_EOL;
							$checked = '';
						}

						// 휴대폰 사용
						if ($default['de_hp_use']) {
							$multi_settle++;
							echo '<input type="radio" id="pp_settle_hp" name="pp_settle_case" value="휴대폰" '.$checked.'> <label for="pp_settle_hp" class="lb_icon hp_icon">휴대폰</label>'.PHP_EOL;
							$checked = '';
						}

						// 신용카드 사용
						if ($default['de_card_use']) {
							$multi_settle++;
							echo '<input type="radio" id="pp_settle_card" name="pp_settle_case" value="신용카드" '.$checked.'> <label for="pp_settle_card" class="lb_icon card_icon">신용카드</label>'.PHP_EOL;
							$checked = '';
						}
						?>

						</div>

						<?php
						if ($default['de_vbank_use'] || $default['de_iche_use'] || $default['de_card_use'] || $default['de_hp_use']) {
							//echo '</fieldset>';
						}

						if ($multi_settle == 0)
							echo '<p class="alert alert-light text-center small py-2 mt-2 mb-0" role="alert">결제할 방법이 없습니다.<br>운영자에게 알려주시면 감사하겠습니다.</p>';
						?>
					</li>
					<li class="list-group-item">
						<?php
						ob_start();
							// 결제대행사별 코드 include (결제대행사 정보 필드 및 주분버튼)
							require_once(G5_MSHOP_PATH.'/'.$default['de_pg_service'].'/orderform.2.php');
						$content = ob_get_contents();
						ob_end_clean();

						$content = str_replace('btn_confirm', 'd-flex gap-2', $content);
						$content = str_replace('<span', '<span class="flex-grow-1 order-2"', $content);
						$content = str_replace('btn_submit', 'btn btn-primary btn-lg w-100 py-3', $content);
						$content = str_replace('btn_cancel', 'btn btn-basic btn-lg order-1 py-3', $content);

						echo $content;
						?>

					</li>
				</ul>
			</section>
		</div>
	</div>

</form>

<?php
if ($default['de_escrow_use']) {
	// 결제대행사별 코드 include (에스크로 안내)
	require_once(G5_MSHOP_PATH.'/'.$default['de_pg_service'].'/orderform.3.php');
}
?>

<div class="modal fade" id="show_progress" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-sm">
		<div class="modal-content">
			<div class="modal-body text-center py-4">
				<div class="d-flex justify-content-center mb-3">
					<div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
					  <span class="visually-hidden">Loading...</span>
					</div>
				</div>
				주문완료 중입니다. 
				<br>
				잠시만 기다려 주십시오.
			</div>
		</div>
	</div>
</div>

<script>
/* 결제방법에 따른 처리 후 결제등록요청 실행 */
var settle_method = "";
var showModal = new bootstrap.Modal(document.getElementById('show_progress'));

function pay_approval()
{
    var f = document.sm_form;
    var pf = document.forderform;

    // 필드체크
    if(!payfield_check(pf))
        return false;

    // 금액체크
    if(!payment_check(pf))
        return false;

    <?php if($default['de_pg_service'] == 'kcp') { ?>
    f.buyr_name.value = pf.pp_name.value;
    f.buyr_mail.value = pf.pp_email.value;
    f.buyr_tel1.value = pf.pp_hp.value;
    f.buyr_tel2.value = pf.pp_hp.value;
    f.rcvr_name.value = pf.pp_name.value;
    f.rcvr_tel1.value = pf.pp_hp.value;
    f.rcvr_tel2.value = pf.pp_hp.value;
    f.rcvr_mail.value = pf.pp_email.value;
    f.settle_method.value = settle_method;
    <?php } else if($default['de_pg_service'] == 'lg') { ?>
    var pay_method = "";
    switch(settle_method) {
        case "계좌이체":
            pay_method = "SC0030";
            break;
        case "가상계좌":
            pay_method = "SC0040";
            break;
        case "휴대폰":
            pay_method = "SC0060";
            break;
        case "신용카드":
            pay_method = "SC0010";
            break;
    }
    f.LGD_CUSTOM_FIRSTPAY.value = pay_method;
    f.LGD_BUYER.value = pf.pp_name.value;
    f.LGD_BUYEREMAIL.value = pf.pp_email.value;
    f.LGD_BUYERPHONE.value = pf.pp_hp.value;
    f.LGD_AMOUNT.value = f.good_mny.value;
    <?php if($default['de_tax_flag_use']) { ?>
    f.LGD_TAXFREEAMOUNT.value = pf.comm_free_mny.value;
    <?php } ?>
    <?php } else if($default['de_pg_service'] == 'inicis') { ?>
    var paymethod = "";
    var width = 330;
    var height = 480;
    var xpos = (screen.width - width) / 2;
    var ypos = (screen.width - height) / 2;
    var position = "top=" + ypos + ",left=" + xpos;
    var features = position + ", width=320, height=440";
    switch(settle_method) {
        case "계좌이체":
            paymethod = "bank";
            break;
        case "가상계좌":
            paymethod = "vbank";
            break;
        case "휴대폰":
            paymethod = "mobile";
            break;
        case "신용카드":
            paymethod = "wcard";
            break;
    }
    f.P_AMT.value = f.good_mny.value;
    f.P_UNAME.value = pf.pp_name.value;
    f.P_MOBILE.value = pf.pp_hp.value;
    f.P_EMAIL.value = pf.pp_email.value;
    <?php if($default['de_tax_flag_use']) { ?>
    f.P_TAX.value = pf.comm_vat_mny.value;
    f.P_TAXFREE = pf.comm_free_mny.value;
    <?php } ?>
    f.P_RETURN_URL.value = "<?php echo $return_url.$pp_id; ?>";
    f.action = "https://mobile.inicis.com/smart/" + paymethod + "/";
    <?php } else if($default['de_pg_service'] == 'nicepay') { ?>

    f.Amt.value       = f.good_mny.value;
    f.BuyerName.value   = pf.pp_name.value;
    f.BuyerEmail.value  = pf.pp_email.value;
    f.BuyerTel.value    = pf.pp_hp.value;

    f.DirectShowOpt.value = "";     // 간편결제 요청 값 초기화
    f.DirectEasyPay.value = "";     // 간편결제 요청 값 초기화
    f.NicepayReserved.value = "";   // 간편결제 요청 값 초기화
    f.EasyPayMethod.value = "";   // 간편결제 요청 값 초기화

        <?php if ($default['de_escrow_use']) {  // 간편결제시 에스크로값이 0이 되므로 기본설정값을 지정 ?>
        f.TransType.value = "1";
        <?php } ?>

    switch(settle_method) {
        case "계좌이체":
            paymethod = "BANK";
            break;
        case "가상계좌":
            paymethod = "VBANK";
            break;
        case "휴대폰":
            paymethod = "CELLPHONE";
            break;
        case "신용카드":
            paymethod = "CARD";
            break;
        default:
            paymethod = "무통장";
            break;
    }
    
    f.PayMethod.value = paymethod;

    <?php if($default['de_tax_flag_use']) { ?>
    f.SupplyAmt.value = pf.comm_tax_mny.value;
    f.GoodsVat.value = pf.comm_vat_mny.value;
    f.TaxFreeAmt.value = pf.comm_free_mny.value;
    <?php } ?>

    if (! nicepay_create_signdata(f)) {
        return false;
    }

    <?php } ?>

    //var new_win = window.open("about:blank", "tar_opener", "scrollbars=yes,resizable=yes");
    //f.target = "tar_opener";

    // 주문 정보 임시저장
    var order_data = $(pf).serialize();
    var save_result = "";
    $.ajax({
        type: "POST",
        data: order_data,
        url: g5_url+"/shop/ajax.orderdatasave.php",
        cache: false,
        async: false,
        success: function(data) {
            save_result = data;
        }
    });

    if(save_result) {
        alert(save_result);
        return false;
    }

    <?php if($default['de_pg_service'] == 'nicepay') { ?>
        nicepayStart(f);

        return;
    <?php } ?>
    f.submit();
}

function forderform_check()
{
    var f = document.forderform;

    // 필드체크
    if(!payfield_check(f))
        return false;

    // 금액체크
    if(!payment_check(f))
        return false;

    if(f.res_cd.value != "0000") {
        alert("결제등록요청 후 결제해 주십시오.");
        return false;
    }

    document.getElementById("display_pay_button").style.display = "none";
    //document.getElementById("show_progress").style.display = "block";
	showModal.show();

    setTimeout(function() {
        f.submit();
    }, 300);
}

// 결제폼 필드체크
function payfield_check(f)
{
    var settle_case = document.getElementsByName("pp_settle_case");
    var settle_check = false;
    for (i=0; i<settle_case.length; i++)
    {
        if (settle_case[i].checked)
        {
            settle_check = true;
            settle_method = settle_case[i].value;
            break;
        }
    }
    if (!settle_check)
    {
        alert("결제방식을 선택하십시오.");
        return false;
    }

    return true;
}

// 결제체크
function payment_check(f)
{
    var tot_price = <?php echo (int)$pp['pp_price']; ?>;

    if (document.getElementById("pp_settle_iche")) {
        if (document.getElementById("pp_settle_iche").checked) {
            if (tot_price < 150) {
                alert("계좌이체는 150원 이상 결제가 가능합니다.");
                return false;
            }
        }
    }

    if (document.getElementById("pp_settle_card")) {
        if (document.getElementById("pp_settle_card").checked) {
            if (tot_price < 1000) {
                alert("신용카드는 1000원 이상 결제가 가능합니다.");
                return false;
            }
        }
    }

    if (document.getElementById("pp_settle_hp")) {
        if (document.getElementById("pp_settle_hp").checked) {
            if (tot_price < 350) {
                alert("휴대폰은 350원 이상 결제가 가능합니다.");
                return false;
            }
        }
    }

    return true;
}
</script>