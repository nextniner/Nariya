<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 멤버십
na_membership('download', '멤버십 회원만 다운로드할 수 있습니다.');