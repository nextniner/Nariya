<?php
$sub_menu = "010400";
include_once('./_common.php');

$g5['title'] = '신고 관리';
include_once (G5_ADMIN_PATH.'/admin.head.php');
?>

준비 중...

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');